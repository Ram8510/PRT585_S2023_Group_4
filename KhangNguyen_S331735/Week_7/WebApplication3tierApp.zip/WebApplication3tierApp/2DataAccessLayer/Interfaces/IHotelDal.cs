﻿using _1CommonInfrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2DataAccessLayer.Interfaces
{
    public interface IHotelDal
    {
        // Getters
        HotelModel? GetById(int HotelId);
        List<HotelModel> GetAll();

        // Actions
        int CreateHotel(HotelModel Hotel);
        void UpdateHotel(HotelModel Hotel);
        void DeleteHotel(int HotelId);
    }
}
