﻿using _1CommonInfrastructure.Models;
using _2DataAccessLayer.Context.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace _2DataAccessLayer.Maps
{
    public static class HotelMapExtensions
    {
        public static HotelModel ToHotelModel(this Hotel src)
        {
            var dst = new HotelModel();

            dst.HotelId = src.HotelId;
            dst.HotelName = src.HotelName;
            dst.HotelAddress = src.HotelAddress;

            return dst;
        }

        public static Hotel ToHotel(this HotelModel src, Hotel dst = null)
        {
            if (dst == null)
            {
                dst = new Hotel();
            }

            dst.HotelId = src.HotelId;
            dst.HotelName = src.HotelName;
            dst.HotelAddress = src.HotelAddress;

            return dst;
        }
    }
}
