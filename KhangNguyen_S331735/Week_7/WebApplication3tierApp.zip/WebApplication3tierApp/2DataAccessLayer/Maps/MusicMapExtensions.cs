﻿using _1CommonInfrastructure.Models;
using _2DataAccessLayer.Context.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace _2DataAccessLayer.Maps
{
    public static class MusicMapExtensions
    {
        public static MusicModel ToMusicModel(this Music src)
        {
            var dst = new MusicModel();

            dst.MusicId = src.MusicId;
            dst.MusicCode = src.MusicCode;
            dst.MusicName = src.MusicName;

            return dst;
        }

        public static Music ToMusic(this MusicModel src, Music dst = null)
        {
            if (dst == null)
            {
                dst = new Music();
            }

            dst.MusicId = src.MusicId;
            dst.MusicCode = src.MusicCode;
            dst.MusicName = src.MusicName;

            return dst;
        }
    }
}
