﻿using _2DataAccessLayer.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<DBEntitiesContext>
{
    public DBEntitiesContext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<DBEntitiesContext>();
        optionsBuilder.UseSqlServer("Server=localhost;Database=schooldb;Uid=sa;Pwd=P@ssw0rd123;Encrypt=False;");

        return new DBEntitiesContext(optionsBuilder.Options);
    }
}