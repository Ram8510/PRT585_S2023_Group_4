﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2DataAccessLayer.Context.Models
{
    public class Hotel
    {
        public int HotelId { get; set; } //int
        public string? HotelName { get; set; } //navchar(400)
        public string? HotelAddress { get; set; } //navchar(400)
    }
}

