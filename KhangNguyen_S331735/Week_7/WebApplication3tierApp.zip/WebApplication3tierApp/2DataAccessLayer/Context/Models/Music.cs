﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2DataAccessLayer.Context.Models
{
    public class Music
    {
        public int MusicId { get; set; } //int
        public string? MusicCode { get; set; } //navchar(400)
        public string? MusicName { get; set; } //navchar(400)
    }
}

