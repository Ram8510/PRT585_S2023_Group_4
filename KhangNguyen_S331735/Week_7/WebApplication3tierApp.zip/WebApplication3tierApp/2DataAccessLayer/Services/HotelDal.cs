﻿using _1CommonInfrastructure.Models;
using _2DataAccessLayer.Context;
using _2DataAccessLayer.Context.Models;
using _2DataAccessLayer.Interfaces;
using _2DataAccessLayer.Maps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2DataAccessLayer.Services
{
    public class HotelDal : IHotelDal
    {
        //private readonly TestDBEntities context;
        private DBEntitiesContext _db;
        public HotelDal(DBEntitiesContext dbctx)
        {
            this._db = dbctx; // new TestDBEntities();
        }


        public List<HotelModel> GetAll()
        {
            var result = _db.Hotels.ToList();

            var returnObject = new List<HotelModel>();
            foreach (var item in result)
            {
                returnObject.Add(item.ToHotelModel());
            }

            return returnObject;
        }

        public HotelModel? GetById(int HotelId)
        {
            var result = _db.Hotels.SingleOrDefault(x => x.HotelId == HotelId);
            return result?.ToHotelModel();
        }


        public int CreateHotel(HotelModel Hotel)
        {
            var newHotel = Hotel.ToHotel();
            _db.Hotels.Add(newHotel);
            _db.SaveChanges();
            return newHotel.HotelId;
        }


        public void UpdateHotel(HotelModel Hotel)
        {
            var existingHotel = _db.Hotels
                .SingleOrDefault(x => x.HotelId == Hotel.HotelId);

            if (existingHotel == null)
            {
                throw new ApplicationException($"Hotel {Hotel.HotelId} does not exist.");
            }
            Hotel.ToHotel(existingHotel);

            _db.Update(existingHotel);
            _db.SaveChanges();
        }

        public void DeleteHotel(int HotelId)
        {
            var efModel = _db.Hotels.Find(HotelId);
            _db.Hotels.Remove(efModel);
            _db.SaveChanges();


        }

    }

}
