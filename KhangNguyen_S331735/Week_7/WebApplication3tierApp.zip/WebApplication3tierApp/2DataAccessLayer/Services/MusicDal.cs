﻿using _1CommonInfrastructure.Models;
using _2DataAccessLayer.Context;
using _2DataAccessLayer.Context.Models;
using _2DataAccessLayer.Interfaces;
using _2DataAccessLayer.Maps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2DataAccessLayer.Services
{
    public class MusicDal : IMusicDal
    {
        //private readonly TestDBEntities context;
        private DBEntitiesContext _db;
        public MusicDal(DBEntitiesContext dbctx)
        {
            this._db = dbctx; // new TestDBEntities();
        }


        public List<MusicModel> GetAll()
        {
            var result = _db.Musics.ToList();

            var returnObject = new List<MusicModel>();
            foreach (var item in result)
            {
                returnObject.Add(item.ToMusicModel());
            }

            return returnObject;
        }

        public MusicModel? GetById(int MusicId)
        {
            var result = _db.Musics.SingleOrDefault(x => x.MusicId == MusicId);
            return result?.ToMusicModel();
        }


        public int CreateMusic(MusicModel Music)
        {
            var newMusic = Music.ToMusic();
            _db.Musics.Add(newMusic);
            _db.SaveChanges();
            return newMusic.MusicId;
        }


        public void UpdateMusic(MusicModel Music)
        {
            var existingMusic = _db.Musics
                .SingleOrDefault(x => x.MusicId == Music.MusicId);

            if (existingMusic == null)
            {
                throw new ApplicationException($"Music {Music.MusicId} does not exist.");
            }
            Music.ToMusic(existingMusic);

            _db.Update(existingMusic);
            _db.SaveChanges();
        }

        public void DeleteMusic(int MusicId)
        {
            var efModel = _db.Musics.Find(MusicId);
            _db.Musics.Remove(efModel);
            _db.SaveChanges();


        }

    }

}
