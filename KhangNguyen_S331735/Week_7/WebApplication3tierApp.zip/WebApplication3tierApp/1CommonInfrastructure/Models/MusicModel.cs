﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace _1CommonInfrastructure.Models
{
    public class HotelModel
    {
        public int HotelId { get; set; } // int
        public string HotelName { get; set; } // nvarchar(400)
        public string HotelAddress { get; set; } // nvarchar(400)

    }

}
