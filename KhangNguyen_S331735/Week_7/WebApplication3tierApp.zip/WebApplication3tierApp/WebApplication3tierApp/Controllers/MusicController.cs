﻿using _2DataAccessLayer.Services;
using _3BusinessLogicLayer.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication3tierApp.Models;

namespace WebApplication3tierApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Produces("application/json")]
    public class MusicController : BaseController
    {

        private readonly IMusicService _MusicService;
        private readonly ILogger<MusicController> _logger;

        public MusicController(IMusicService MusicService, ILogger<MusicController> logger)
        {
            _MusicService = MusicService;
            _logger = logger;
        }

        [HttpGet("", Name = "GetAllMusics")]
        public async Task<List<MusicDto>> GetAll()
        {
            var result = await _MusicService.GetAll();
            return result.Select(x => x.ToMusicDto()).ToList();
        }

        [HttpGet("{MusicId}", Name = "GetMusic")]
        public async Task<MusicDto?> Get(int MusicId)
        {
            var result = await _MusicService.GetById(MusicId);
            return result?.ToMusicDto();
        }

        [HttpPost, Route("")]
        public async Task<int> Create([FromBody] MusicDto requestDto)
        {
            var MusicModel = requestDto.ToMusicModel();
            return await _MusicService.CreateMusic(MusicModel);
        }

        [HttpPut, Route("update")]
        public async Task<IActionResult> Update([FromBody] MusicDto requestDto)
        {
            await _MusicService.UpdateMusic(requestDto.ToMusicModel());
            return Ok();
        }

        [HttpDelete, Route("{MusicId}")]
        public async Task<IActionResult> Delete(int MusicId)
        {
            await _MusicService.DeleteMusic(MusicId);
            return Ok();
        }
    }
}
