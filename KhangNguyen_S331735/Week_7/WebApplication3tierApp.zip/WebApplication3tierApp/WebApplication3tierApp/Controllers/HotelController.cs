﻿using _2DataAccessLayer.Services;
using _3BusinessLogicLayer.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication3tierApp.Models;

namespace WebApplication3tierApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Produces("application/json")]
    public class HotelController : BaseController
    {

        private readonly IHotelService _HotelService;
        private readonly ILogger<HotelController> _logger;

        public HotelController(IHotelService HotelService, ILogger<HotelController> logger)
        {
            _HotelService = HotelService;
            _logger = logger;
        }

        [HttpGet("", Name = "GetAllHotels")]
        public async Task<List<HotelDto>> GetAll()
        {
            var result = await _HotelService.GetAll();
            return result.Select(x => x.ToHotelDto()).ToList();
        }

        [HttpGet("{HotelId}", Name = "GetHotel")]
        public async Task<HotelDto?> Get(int HotelId)
        {
            var result = await _HotelService.GetById(HotelId);
            return result?.ToHotelDto();
        }

        [HttpPost, Route("")]
        public async Task<int> Create([FromBody] HotelDto requestDto)
        {
            var HotelModel = requestDto.ToHotelModel();
            return await _HotelService.CreateHotel(HotelModel);
        }

        [HttpPut, Route("update")]
        public async Task<IActionResult> Update([FromBody] HotelDto requestDto)
        {
            await _HotelService.UpdateHotel(requestDto.ToHotelModel());
            return Ok();
        }

        [HttpDelete, Route("{HotelId}")]
        public async Task<IActionResult> Delete(int HotelId)
        {
            await _HotelService.DeleteHotel(HotelId);
            return Ok();
        }
    }
}
