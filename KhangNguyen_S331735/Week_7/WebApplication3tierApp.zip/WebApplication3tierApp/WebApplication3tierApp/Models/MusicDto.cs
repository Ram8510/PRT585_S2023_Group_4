﻿using _1CommonInfrastructure.Models;

namespace WebApplication3tierApp.Models
{
    public class MusicDto
    {
        public int MusicId { get; set; }
        public string MusicName { get; set; }
        public string MusicAddress { get; set; }
                        
    }

    public static class MusicDtoMapExtensions
    {
        public static MusicDto ToMusicDto(this MusicModel src)
        {
            var dst = new MusicDto();
            dst.MusicId = src.MusicId;
            dst.MusicCode = src.MusicCode;
            dst.MusicName = src.MusicName;
            return dst;
        }

        public static MusicModel ToMusicModel(this MusicDto src)
        {
            var dst = new MusicModel();
            dst.MusicId = src.MusicId;
            dst.MusicCode = src.MusicCode;
            dst.MusicName = src.MusicName;
            return dst;
        }
    }
}
