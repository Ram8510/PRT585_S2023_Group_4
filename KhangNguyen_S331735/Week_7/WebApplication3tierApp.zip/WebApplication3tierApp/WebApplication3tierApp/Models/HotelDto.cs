﻿using _1CommonInfrastructure.Models;

namespace WebApplication3tierApp.Models
{
    public class HotelDto
    {
        public int HotelId { get; set; }
        public string HotelName { get; set; }
        public string HotelAddress { get; set; }
                        
    }

    public static class HotelDtoMapExtensions
    {
        public static HotelDto ToHotelDto(this HotelModel src)
        {
            var dst = new HotelDto();
            dst.HotelId = src.HotelId;
            dst.HotelName = src.HotelName;
            dst.HotelAddress = src.HotelAddress;
            return dst;
        }

        public static HotelModel ToHotelModel(this HotelDto src)
        {
            var dst = new HotelModel();
            dst.HotelId = src.HotelId;
            dst.HotelName = src.HotelName;
            dst.HotelAddress = src.HotelAddress;
            return dst;
        }
    }
}
