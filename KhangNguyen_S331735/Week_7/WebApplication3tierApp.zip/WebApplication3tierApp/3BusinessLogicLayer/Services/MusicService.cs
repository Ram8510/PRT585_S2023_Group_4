﻿

using _1CommonInfrastructure.Models;
using _2DataAccessLayer.Interfaces;
using _3BusinessLogicLayer.Interfaces;

namespace _3BusinessLogicLayer.Services
{
    public class MusicService :  IMusicService
    {
        private readonly IMusicDal _MusicDal;
        //private readonly IMusicBalService _MusicBalService;
        public MusicService(IMusicDal MusicDal
        //ILoggingService loggingService,
        //IMusicDal MusicDal,
        //IAuditDal auditDal
       // IMusicBalanceService balsvc
        ) 
        {
            _MusicDal = MusicDal;
            // _MusicBalService = balsvc;
        }

        public async Task<MusicModel?> GetById(int MusicId)
        {           
            return _MusicDal.GetById(MusicId);
        }

        public async Task<List<MusicModel>> GetAll()
        {            
            return _MusicDal.GetAll();
        }

        public async Task<int> CreateMusic(MusicModel Music)
        {
            //write validations here
            var newMusicId = _MusicDal.CreateMusic(Music);
            return newMusicId;
        }

        public async Task UpdateMusic(MusicModel Music)
        {
            //write validations here 
            _MusicDal.UpdateMusic(Music);
        }

        public async Task DeleteMusic(int MusicId)
        {            
            try
            {
                //if(balservice.getBal(MusicId) = 0)
                _MusicDal.DeleteMusic(MusicId);
            }
            catch (Exception e)
            {
                //_loggingService.WriteLog(LoggingLevel.Error, "Layer", $"Error delete Music Id:{MusicId}. {e.Message}", e.StackTrace);
            }
        }
    }
}
