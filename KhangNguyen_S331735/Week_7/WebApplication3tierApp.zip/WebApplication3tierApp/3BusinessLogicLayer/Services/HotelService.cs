﻿

using _1CommonInfrastructure.Models;
using _2DataAccessLayer.Interfaces;
using _3BusinessLogicLayer.Interfaces;

namespace _3BusinessLogicLayer.Services
{
    public class HotelService :  IHotelService
    {
        private readonly IHotelDal _HotelDal;
        //private readonly IHotelBalService _HotelBalService;
        public HotelService(IHotelDal HotelDal
        //ILoggingService loggingService,
        //IHotelDal HotelDal,
        //IAuditDal auditDal
       // IHotelBalanceService balsvc
        ) 
        {
            _HotelDal = HotelDal;
            // _HotelBalService = balsvc;
        }

        public async Task<HotelModel?> GetById(int HotelId)
        {           
            return _HotelDal.GetById(HotelId);
        }

        public async Task<List<HotelModel>> GetAll()
        {            
            return _HotelDal.GetAll();
        }

        public async Task<int> CreateHotel(HotelModel Hotel)
        {
            //write validations here
            var newHotelId = _HotelDal.CreateHotel(Hotel);
            return newHotelId;
        }

        public async Task UpdateHotel(HotelModel Hotel)
        {
            //write validations here 
            _HotelDal.UpdateHotel(Hotel);
        }

        public async Task DeleteHotel(int HotelId)
        {            
            try
            {
                //if(balservice.getBal(HotelId) = 0)
                _HotelDal.DeleteHotel(HotelId);
            }
            catch (Exception e)
            {
                //_loggingService.WriteLog(LoggingLevel.Error, "Layer", $"Error delete Hotel Id:{HotelId}. {e.Message}", e.StackTrace);
            }
        }
    }
}
