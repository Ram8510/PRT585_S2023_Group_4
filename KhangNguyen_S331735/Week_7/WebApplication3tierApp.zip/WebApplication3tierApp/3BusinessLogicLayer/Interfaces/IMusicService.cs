﻿using _1CommonInfrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3BusinessLogicLayer.Interfaces
{
    public interface IMusicService
    {
        Task<MusicModel?> GetById(int MusicId);
        Task<List<MusicModel>> GetAll();

        Task<int> CreateMusic(MusicModel Music);
        Task UpdateMusic(MusicModel Music);
        Task DeleteMusic(int MusicId);
    }
}
